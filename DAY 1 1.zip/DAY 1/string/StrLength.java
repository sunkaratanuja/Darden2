package com.string;

public class StrLength {

	public static void main(String[] args) {
		//declaring a string
		
		String str="Hello World";
		
		//using string method
		
		int counter=str.length();
		
		System.out.println("The string has"  + counter +   "Characters");

	}

}

package com.stringBuilder;

public class StrInsert {
		public static void main(String[] args) {
			//declaring string
			StringBuilder add=new StringBuilder("It is used to at the specified index position");
			//insert method
			add.insert(13," insert text ");
			System.out.println(add);

		}

	}

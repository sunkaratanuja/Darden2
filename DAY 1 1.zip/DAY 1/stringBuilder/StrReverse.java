package com.stringBuilder;

public class StrReverse {

		public static void main(String[] args) {
			//declaring string
			StringBuilder rev=new StringBuilder("This method returns the reversed object on which it was called");
			//reverse string
			System.out.println(rev.reverse());

		}

	}


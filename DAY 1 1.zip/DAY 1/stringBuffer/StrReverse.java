package com.stringBuffer;

public class StrReverse {

	public static void main(String[] args) {
		//declaring string
		StringBuffer rev=new StringBuffer("This method returns the reversed object on which it was called");
		//reverse string
		System.out.println(rev.reverse());

	}

}
